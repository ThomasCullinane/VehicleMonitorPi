#!/bin/bash
touch ./files.txt 
touch ./tmpexceptions.txt 

timestamp() {
  date +"%T" # current time
}

for file in '/run/user/1000/gvfs/google-drive:host=gmail.com,user=satchastrong/10r14S-l9iDt6xxP-T5eYwA48f-TgSs5S/1mZnhn4rQT-rs_uDP_DvVFRvwTzYLL2w3/'*; do
	printf "$file\n">>./files.txt 

    while read line; do    	
    	if [[ "$line" == *"exception"* ]]; then
    		printf '%s\n' "$line" >> ./tmpexceptions.txt
    		echo "exception" 
    	fi
    done < $file
    sleep 1
    mv $file ./sensor/sensor_$(timestamp).txt
    echo "file complete"
done
echo "run complete"

sort -no tmpexceptions.txt tmpexceptions.txt

#tweet=tail -1 tmpexceptions.txt | awk '{print $1$2" " $7" " $8}'

touch "/run/user/1000/gvfs/google-drive:host=gmail.com,user=satchastrong/10r14S-l9iDt6xxP-T5eYwA48f-TgSs5S/1tHkEYMxI4TpCZeLj37hlqV45X-7BFdzj/$(tail -1 tmpexceptions.txt | awk '{print $1$2" " $7" " $8}')"
